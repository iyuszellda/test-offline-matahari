import React, { Component } from 'react'
// import ListStudent from './ListStudent'

export default class FormStudent extends Component {
    // state
    constructor() {
        super()
        this.state = {
            currentStudentName: '',
            currentStudentAge: ''
        }
    }
    addNewStudent() {
        this.props.addStudent(this.state.currentStudentName, this.state.currentStudentAge)
    }

    render() {
        return (
            <div>
                <div style={ stylesDiv.div }>
                    <form>
                    <label style={ stylesDiv.label }>Student Name: { this.state.currentStudentName }</label>
                    <input style={ stylesForm.input } type="text" name="student_name" placeholder="Student Name" required onChange={(e) => this.setState({ currentStudentName : e.target.value})} />
                    
                    <label style={ stylesDiv.label }>Age: { this.state.currentStudentAge }</label>
                    <input style={ stylesForm.input } type="text" name="age" placeholder="Age" onChange={(e) => this.setState({ currentStudentAge : e.target.value})} />
                    
                    <input style={ stylesSubmit.submit } type="button" name="btn" value="Submit" onClick={() => this.addNewStudent() } />
                    
                    </form>
                </div>
            </div>
        )
    }
}

const stylesDiv = {
    div: {
        margin: 'auto',
        width: '30%',
        borderRadius: '5px',
        backgroundColor: '#f2f2f2',
        padding: '20px',
        border: '3px solid #5bc0de',
        color: '#000000'
    },
    label: {
        textAlign: 'left', 
        color: '#000000'
    }
}

const stylesForm = {
    input: {
        width: '100%',
        padding: '12px 20px',
        margin: '8px 0',
        display: 'inline-block',
        border: '1px solid #ccc',
        borderRadius: '4px',
        boxSizing: 'border-box'
      }
}

const stylesSubmit = {
    submit: {
        width: '100%',
        backgroundColor: '#428bca',
        color: '#FFFFFF',
        padding: '14px 20px',
        margin: '8px 0',
        border: 'none',
        borderRadius: '4px',
        cursor: 'pointer'
    }
}
