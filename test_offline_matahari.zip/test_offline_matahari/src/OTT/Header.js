import React, { Component } from 'react'
import { Link } from 'react-router-dom'

const posts = [
    {id: 1, title: 'Home', path: "/"},
    {id: 2, title: 'Add Student', path: "/addstudent"},
    {id: 3, title: 'Contact', path: "/contact"}
  ];

const styles = {
  menuLi: {
    display: 'inline-block',
    padding: '10px'
  },
  text: {
    color: '#ffffff',
  }
}
  
function Menu(props) {
    const sidebar = (
      <ul>
        {props.posts.map((post) => 
          <li key={post.id} style={ styles.menuLi }>
            <Link style={ styles.text } to={post.path}>{post.title}</Link>
          </li> )}
      </ul>
    );
    
    return (
      <div>
        {sidebar}
      </div>
    );
  }
  
export default class Header extends Component {
    render() {
        return (
        <div>
            <h1>
                Students
            </h1>
            <Menu posts={posts}/>
        </div>
        )
    }
}
