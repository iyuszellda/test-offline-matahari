import React from 'react'

const Homepage = (props) => (
    <div>
        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin mollis purus in neque rutrum, ac commodo justo rutrum. Nullam molestie justo diam, et pretium turpis vulputate quis. Etiam sit amet diam lobortis, egestas massa sed, tincidunt ante. Etiam nulla velit, semper sed ante sit amet, maximus finibus ipsum. Maecenas libero metus, sagittis at vehicula at, sollicitudin vel justo. Proin mollis lorem at scelerisque mollis. Suspendisse rutrum quam quis faucibus feugiat. Etiam semper ultricies orci, ut finibus orci imperdiet eget. Quisque ornare libero in diam ultrices, non interdum urna suscipit.

Integer vel magna nulla. Donec odio massa, facilisis nec mattis vitae, molestie quis velit. Nunc et tempor lorem. Maecenas tortor eros, volutpat ut maximus vel, finibus quis orci. Proin eleifend risus sem, sit amet scelerisque mauris pellentesque at. Praesent faucibus vitae tellus id tempor. Donec non justo eu est pulvinar ornare quis sed mi. Vivamus a congue ligula.

In hac habitasse platea dictumst. Nunc eu lorem facilisis, mattis odio ultricies, elementum turpis. Phasellus placerat diam eget magna laoreet, sit amet cursus nisl rutrum. Aliquam ac justo dapibus, tempor sapien in, imperdiet lorem. In ut sem sed urna aliquet mattis id id metus. Vestibulum ligula sapien, venenatis vel mattis ut, bibendum non elit. Nam dictum massa vehicula ante fermentum laoreet. Duis gravida velit fermentum nulla dapibus volutpat a id enim. Ut eu vulputate quam, vitae imperdiet dolor. Pellentesque suscipit nulla felis, non tincidunt leo eleifend vel. Morbi ac fermentum tortor. Donec a magna nec enim malesuada auctor at porttitor mauris.

Aliquam erat volutpat. In sed dapibus ligula. Vivamus non vulputate urna. Nunc in orci et elit placerat tincidunt. Proin at vehicula purus. Proin ullamcorper imperdiet orci, fringilla finibus ipsum facilisis ac. Aenean sed blandit tortor. Proin in quam at dui porta congue quis sit amet turpis. In vitae convallis lacus.

Proin ac placerat turpis, vitae feugiat felis. Maecenas ornare, ex sed condimentum blandit, nisl elit placerat erat, et condimentum mi tortor in magna. Curabitur arcu risus, volutpat ut ultricies eu, egestas et justo. Pellentesque urna risus, tristique vitae lectus non, aliquam auctor lorem. Cras tincidunt faucibus nibh id aliquam. Phasellus cursus erat vel ullamcorper hendrerit. Mauris consectetur id tortor non pulvinar. Curabitur efficitur odio eget dui commodo pulvinar. Fusce vel lacinia lectus, eget feugiat quam.
    </div>
)
export default Homepage