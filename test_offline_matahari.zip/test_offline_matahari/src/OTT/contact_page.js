import React from 'react'

const ListPage = (props) => (
    <div>
        <ul>
            <li>My Email: iyuszellda@gmail.com</li>
            <li>My Phone: 085319106397</li>
        </ul>
    </div>
)
export default ListPage