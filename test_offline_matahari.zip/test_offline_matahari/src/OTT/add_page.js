import React, { Component } from 'react'
import Form from './FromStudent'
import ListStudent from './ListStudent'

export default class AddForm extends Component {
    constructor(){
        super()
        this.state = {
          students: [
            { name: 'Yustinus', age: 28 }
          ],
        }
    }
      
    addStudent(name, age) {
        let currentStudents = this.state.students
        let newStudent = { name, age }
        currentStudents.push(newStudent)
        this.setState({
            students: currentStudents
        })
    }
    render() {
        return(
            <div className="App">
                <Form addStudent={ (name, age) => this.addStudent(name, age) }/>
                <h3>List Students:</h3>
                <ListStudent students={ this.state.students } />
            </div>
        )
      }     
}
