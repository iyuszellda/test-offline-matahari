import React, { Component } from 'react'

export default class ListStudent extends Component {
    render() {
        return (
            <div>
                <ul>
                    {
                        this.props.students.map( (student, idx) => {
                            return <li style={ styles.menuLi } key={idx}>{ student.name }, age { student.age }</li>
                        })
                    }
                </ul>
            </div>
        )
    }
}

const styles = {
    menuLi: {
      display: 'table',
      padding: '10px',
      margin: 'auto'
    }
  }