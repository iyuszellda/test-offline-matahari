import React, { Component } from 'react';
// import logo from './logo.svg';
import background from './background-blur-blurred.jpg';
import './App.css';

import Header from './OTT/Header'
import { BrowserRouter as Router, Route, Link } from 'react-router-dom'

import HomePage from './OTT/home_page'
import AddPage from './OTT/add_page'
import ContactPage from './OTT/contact_page';
// import { Button } from 'react-bootstrap';

export default class App extends Component {
  render() {
    return (
        <Router>
            <div style={style.bg} className="App">
              <Header/>
              <Route path="/" exact component={ HomePage } />
              <Route path="/addstudent" exact component={ AddPage } />
              <Route path="/contact" exact component={ ContactPage } />
            </div>
        </Router>
    );
  }
}

const style = {
  bg: {
    backgroundImage: 'url(' + background + ')',
    height: '100%',
    color: '#ffffff',
    backgroundPosition: 'center',
    backgroundRepeat: 'no-repeat',
    backgroundSize: 'cover',
  }
};

// function App() {
//   return (
//     <div className="App">
//       <header className="App-header">
//         <img src={logo} className="App-logo" alt="logo" />
//         <p>
//           Edit <code>src/App.js</code> and save to reload.
//         </p>
//         <h1>Testing 1</h1>
//         <a
//           className="App-link"
//           href="https://reactjs.org"
//           target="_blank"
//           rel="noopener noreferrer"
//         >
//           Learn React
//         </a>
//       </header>
//     </div>
//   );
// }

// export default App;
